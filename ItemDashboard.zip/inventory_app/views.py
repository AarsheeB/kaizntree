# inventory_app/views.py


from django.shortcuts import get_object_or_404
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.generics import ListCreateAPIView
from .models import Item
from .serializers import ItemSerializer

from django.shortcuts import render


def create_account(request):
    username = request.data.get('username')
    password = request.data.get('password')

    # Add your account creation logic here

    return Response(status=status.HTTP_201_CREATED)

def login_view(request):
    return render(request, 'login.html')

class ItemListCreateView(APIView):
    def post(self, request, format=None):
        serializer = ItemSerializer(data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    def get(self, request, *args, **kwargs):
        items = Item.objects.all()
        serializer = ItemSerializer(items, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

class ItemDetailView(APIView):
    def get(self, request, item_id):
        item = get_object_or_404(Item, id=item_id)
        serializer = ItemSerializer(item)
        return Response(serializer.data)
    
class ItemDeleteView(APIView):
    def delete(self, request, item_id):
        item = get_object_or_404(Item, id=item_id)
        item.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
    
class TagListCreateView(APIView):
    def get(self, request, format=None):
        tags = Item.objects.values_list('tags', flat=True).distinct()
        return Response(tags)


class CategoryListCreateView(APIView):
    def get(self, request, format=None):
        categories = Item.objects.all()
        serializer = ItemSerializer(categories, many=True)
        return Response(serializer.data)

    def post(self, request, format=None):
        serializer = ItemSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

