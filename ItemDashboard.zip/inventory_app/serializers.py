# inventory_app/serializers.py

from rest_framework import serializers
from .models import Category, Tag, Item

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = '__all__'

class TagSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tag
        fields = '__all__'

class ItemSerializer(serializers.ModelSerializer):
    tags = TagSerializer(many=True)
    category = CategorySerializer(required=False, allow_null=True)
    
    class Meta:
        model = Item
        fields = '__all__'

    def create(self, validated_data):
        tags_data = validated_data.pop('tags', [])
        category_data = validated_data.pop('category', None)

        # Create tags
        tags = [Tag.objects.create(**tag_data) for tag_data in tags_data]

        # Create item with tags
        item = Item.objects.create(**validated_data)
        item.tags.set(tags)

        # Associate category if provided
        if category_data:
            category_instance, _ = Category.objects.get_or_create(**category_data)
            item.category = category_instance
            item.save()

        return item
