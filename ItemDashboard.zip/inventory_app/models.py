# inventory_app/models.py

from django.db import models

class Category(models.Model):
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name

class Tag(models.Model):
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name

class Item(models.Model):
    sku = models.CharField(max_length=50, unique=True)
    name = models.CharField(max_length=255)
    category = models.ForeignKey(Category, null=True, blank=True, on_delete=models.SET_NULL)
    tags = models.ManyToManyField(Tag)
    stock_status = models.CharField(max_length=20, choices=[('In Stock', 'In Stock'), ('Out of Stock', 'Out of Stock')])
    available_stock = models.PositiveIntegerField()
    

    def __str__(self):
        return self.name

# Explicitly set app_label for each model
Category._meta.app_label = 'inventory_app'
Tag._meta.app_label = 'inventory_app'
Item._meta.app_label = 'inventory_app'
