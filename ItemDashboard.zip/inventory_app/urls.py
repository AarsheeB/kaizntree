# inventory_app/urls.py

from .views import ItemDetailView, ItemDeleteView
from django.urls import path
from .views import CategoryListCreateView, TagListCreateView, ItemListCreateView
from .views import login_view
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView

urlpatterns = [
    path('categories/', CategoryListCreateView.as_view(), name='category-list-create'),
    path('tags/', TagListCreateView.as_view(), name='tag-list-create'),
    path('items/', ItemListCreateView.as_view(), name='item-list-create'),
    path('login/', login_view, name='login'),
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('api/items/<int:item_id>/', ItemDetailView.as_view(), name='item-detail'),
    path('api/items/<int:item_id>/delete/', ItemDeleteView.as_view(), name='item-delete'),
]
