# restful_project/urls.py

from .views import ItemDetailView
from django.contrib import admin
from django.urls import path, include
from inventory_app.views import ItemListCreateView, CategoryListCreateView  # Import the views

urlpatterns = [
    urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include('inventory_app.urls')),
    path('api/items/', ItemListView.as_view(), name='item-list'),# Include the URLs of your app
    # Other URL patterns for your project
    path('api/items/<int:item_id>/', ItemDetailView.as_view(), name='item-detail'),
    path('api/create-account/', create_account, name='create_account'),
]

]
